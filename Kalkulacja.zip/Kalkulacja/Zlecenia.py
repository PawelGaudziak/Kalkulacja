import pymysql
from DB import *

class Zlecenia(DB):

    def __init__(self):
        super().__init__();
        print("Tutaj Zlecenia")

        Klienci_id_klienta = input("Podaj nr id klienta: ")
        naklad = input("Podaj nakład do druku: ")
        gramatura = input("Podaj gramaturę w gramach: ")
        Papier_id_p = input("Podaj rodzaj papieru: 1-kreda błysk, 2-kreda mat, 3-offset ")
        Rodzaj_pracy_id_r = input("Podaj rodzaj zlecenia: 1-ulotka, 2-plakat, 3-broszura, 4-praca kartonowa ")
        Format_ulotki_id_u = input("Podaj format ulotki: 1-A4, 2-A5, 3-A6, 4-DL, 5-2DL ")
        self.c.execute("INSERT INTO zlecenia (Klienci_id_klienta, naklad, gramatura, Papier_id_p, Rodzaj_pracy_id_r, Format_ulotki_id_u, data_zlozenia) VALUES (%s,%s,%s,%s,%s,%s, NOW())",
                       (Klienci_id_klienta, naklad, gramatura, Papier_id_p, Rodzaj_pracy_id_r, Format_ulotki_id_u, data_zlozenia))


        dec = input("Dodać zlecenie? T/N").upper()

        if (dec == "T"):
            self.conn.commit()
        else:
            self.conn.rollback()





        #obj = zlecenia()
#INSERT INTO kosz(nazwa, data) VALUES ("cos", NOW());
#self.c.execute("INSERT INTO zlecenia (data) VALUES ("cos", NOW());
#INSERT INTO kalkulacja.zlecenia (Klienci_id_klienta, naklad, gramatura, Papier_id_p, Rodzaj_pracy_id_r, Format_ulotki_id_u, data_zlozenia) VALUES (3,2000,115,1,1,1, NOW());