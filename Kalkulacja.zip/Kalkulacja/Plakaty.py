import pymysql
from DB import *

class Plakaty(DB):

    def __init__(self):
        super().__init__();
        print("Tutaj Zlecenia na plakaty")