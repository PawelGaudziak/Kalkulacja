import pymysql

class DB:
    def __init__(self):
        self.conn = pymysql.connect('localhost', 'root', 'Fragles21', 'kalkulacja', charset='utf8')
        self.c=self.conn.cursor()