from Home import *

dec = int(input("1 - Logowanie / 2 - Rejestracja "))

if (dec == 1):
    obj = Logowanie()
elif (dec == 2):
    obj = Rejestracja()
    obj = Logowanie()