import pymysql
from DB import *

class Ulotki(DB):

    def __init__(self):
        super().__init__();
        print("Tutaj Zlecenia na ulotki")

        while (True):

            try:
                Klienci_id_klienta = int(input("Podaj nr id klienta: "))
                break
            except:
                print("Podałeś złą wartość, spróbuj jeszcze raz.")
        while (True):

            try:
                naklad = int(input("Podaj nakład do druku: "))
                break
            except:
                print("Podałeś złą wartość, spróbuj jeszcze raz.")

        while (True):

            try:
                gramatura = int(input("Podaj gramaturę w gramach: "))
                break
            except:
                print("Podałeś złą wartość, spróbuj jeszcze raz.")

        while (True):

            try:
                Papier_id_p = int(input("Podaj rodzaj papieru: 1-kreda błysk, 2-kreda mat, 3-offset "))
                break
            except:
                print("Podałeś złą wartość, spróbuj jeszcze raz.")


        while (True):

            try:
                Format_ulotki_id_u = int(input("Podaj format ulotki: 1-A4, 2-A5, 3-A6, 4-DL, 5-2DL "))


                self.c.execute("INSERT INTO zlecenia (Klienci_id_klienta, naklad, gramatura, Papier_id_p,  Format_ulotki_id_u, Rodzaj_pracy_id_r, data_zlozenia) VALUES (%s,%s,%s,%s,%s,1, NOW())",
                               (Klienci_id_klienta, naklad, gramatura, Papier_id_p, Format_ulotki_id_u))



                dec = input("Dodać zlecenie? T/N").upper()

                if (dec == "T"):
                    self.conn.commit()
                else:
                    self.conn.rollback()
                    #break

                break

            except:
                print("Podałeś złą wartość, spróbuj jeszcze raz.")










"""
        Klienci_id_klienta = input("Podaj nr id klienta: ")
        naklad = input("Podaj nakład do druku: ")
        gramatura = input("Podaj gramaturę w gramach: ")
        Papier_id_p = input("Podaj rodzaj papieru: 1-kreda błysk, 2-kreda mat, 3-offset ")
        #Rodzaj_pracy_id_r = input("Podaj rodzaj zlecenia: 1-ulotka, 2-plakat, 3-broszura, 4-praca kartonowa ")
        Format_ulotki_id_u = input("Podaj format ulotki: 1-A4, 2-A5, 3-A6, 4-DL, 5-2DL")
        self.c.execute(
            "INSERT INTO zlecenia (Klienci_id_klienta, naklad, gramatura, Papier_id_p, Format_ulotki_id_u, Rodzaj_pracy_id_r, data_zlozenia) VALUES (%s,%s,%s,%s,%s, 1, NOW())",
            (Klienci_id_klienta, naklad, gramatura, Papier_id_p, Format_ulotki_id_u))

        dec = input("Dodać zlecenie na ulotki? T/N").upper()

        if (dec == "T"):
            self.conn.commit()
        else:
            self.conn.rollback()
"""