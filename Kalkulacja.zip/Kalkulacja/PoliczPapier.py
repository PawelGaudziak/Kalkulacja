import pymysql
from DB import *


class PoliczPapier(DB):

    def __init__(self):
        super().__init__();

        print("Tutaj PoliczPapier")

        while (True):

            try:
                id_zlecenia = int(input("Podaj id zlecenia: "))
                break
            except:
                print("Podałeś złą wartość, spróbuj jeszcze raz.")

        while (True):
            try:
                cena_za_kg = float(input("Podaj cenę za kg: "))
                #break
            except:
                print("Podałeś złą wartość, spróbuj jeszcze raz.")
            else:
                break

        while (True):
            try:
                FPU_id_fp = int(input("Podaj format do druku: 1-A1+, 2-A2+: "))  # FPU_id_fp,  z_format_pap_ulotka

                self.c.execute("select ceil(zl.naklad/fpu.ilosc_ul_arkusz) as ilosc_arkuszy_do_druku, "
                               "round((zl.gramatura*fp.wsp*zl.naklad/fpu.ilosc_ul_arkusz/1000),2) as waga_papieru, "
                               "round(ceil((zl.gramatura*fp.wsp*zl.naklad/fpu.ilosc_ul_arkusz/1000*(%s))),2) as cena_papieru, "
                               "zl.naklad, zl.Format_ulotki_id_u, fpu.FPU_id_fp, zl.z_format_pap_ulotka "  # fpu.FPU_id_fp zamiast zl.z_format_pap_ulotka
                               "from zlecenia as zl "
                               "join format_pap_ulotka as fpu on zl.format_ulotki_id_u = fpu.fpu_id_u "
                               "join formatpapieru as fp on fp.id_fp=fpu.fpu_id_fp "
                               "where zl.id_zlecenia=%s and fpu.fpu_id_fp=%s",
                               (cena_za_kg, id_zlecenia, FPU_id_fp))
                dane = self.c.fetchall()  # zwraca wartość z executa

                self.c.execute(
                    "update zlecenia set cena_za_kg=%s, waga_papieru=%s, cena_papieru=%s, ilosc_arkuszy_do_druku=%s where id_zlecenia=%s",
                    (cena_za_kg, dane[0][1], dane[0][2], dane[0][0], id_zlecenia))

                dec = input("Wykonać kalkulację? T/N").upper()

                if (dec == "T"):
                    self.conn.commit()
                else:
                    self.conn.rollback()

                break

            except:
                print("Podałeś złą wartość, spróbuj jeszcze raz.")





"""
działa
            def __init__(self):
                super().__init__();
                print("Tutaj PoliczPapier")

                cena_za_kg = input("Podaj cenę za kg: ")
                id_zlecenia = input("Podaj id zlecenia: ")
                FPU_id_fp = input("Podaj format do druku: 1-A1+, 2-A2+: ")  # FPU_id_fp,  z_format_pap_ulotka
                self.c.execute("select ceil(zl.naklad/fpu.ilosc_ul_arkusz) as ilosc_arkuszy_do_druku, "
                               "round((zl.gramatura*fp.wsp*zl.naklad/fpu.ilosc_ul_arkusz/1000),2) as waga_papieru, "
                               "round(ceil((zl.gramatura*fp.wsp*zl.naklad/fpu.ilosc_ul_arkusz/1000*(%s))),2) as cena_papieru, "
                               "zl.naklad, zl.Format_ulotki_id_u, fpu.FPU_id_fp, zl.z_format_pap_ulotka "  # fpu.FPU_id_fp zamiast zl.z_format_pap_ulotka
                               "from zlecenia as zl join format_pap_ulotka as fpu on zl.format_ulotki_id_u = fpu.fpu_id_u join formatpapieru as fp on fp.id_fp=fpu.fpu_id_fp where zl.id_zlecenia=%s and fpu.fpu_id_fp=%s",
                               # (ilosc_ark_do_druku, waga_papieru, cena_papieru, naklad, format_ulotki_id_u, FPU_id_fp))
                               (cena_za_kg, id_zlecenia, FPU_id_fp))
                dane = self.c.fetchall()  # zwraca wartość z executa

                # print(dane)
                # print(dane[0][0], dane[0][1], dane[0][2], dane[0][3], dane[0][4], dane[0][5])
                # self.c.execute("update zlecenia set cena_za_kg=%s, waga_papieru=%s, cena_papieru=%s, ilosc_arkuszy_do_druku=%s  where id_zlecenia=%s", (cena_za_kg, dane[0][1], dane[0][2], dane[0][0]))
                self.c.execute(
                    "update zlecenia set cena_za_kg=%s, waga_papieru=%s, cena_papieru=%s, ilosc_arkuszy_do_druku=%s where id_zlecenia=%s",
                    (cena_za_kg, dane[0][1], dane[0][2], dane[0][0], id_zlecenia))
"""

"""
nie działą
cena_za_kg = input("Podaj cenę za kg: ")
        id_zlecenia = input("Podaj id zlecenia: ")
        z_format_pap_ulotka = input("Podaj format do druku: 1-A1+, 2-A2+: ")  #FPU_id_fp,  z_format_pap_ulotka
        self.c.execute("select ceil(zl.naklad/fpu.ilosc_ul_arkusz) as ilosc_arkuszy_do_druku, "
                       "round((zl.gramatura*fp.wsp*zl.naklad/fpu.ilosc_ul_arkusz/1000),2) as waga_papieru, "
                       "round(ceil((zl.gramatura*fp.wsp*zl.naklad/fpu.ilosc_ul_arkusz/1000*(%s))),2) as cena_papieru, "
                       "zl.naklad, zl.Format_ulotki_id_u, fpu.FPU_id_fp, zl.z_format_pap_ulotka " #fpu.FPU_id_fp zamiast zl.z_format_pap_ulotka
                       "from zlecenia as zl join format_pap_ulotka as fpu on zl.format_ulotki_id_u = fpu.fpu_id_u join formatpapieru as fp on fp.id_fp=zl.z_format_pap_ulotka where zl.id_zlecenia=%s and zl.z_format_pap_ulotka=%s",
                       # (ilosc_ark_do_druku, waga_papieru, cena_papieru, naklad, format_ulotki_id_u, FPU_id_fp))
                       (cena_za_kg, id_zlecenia, z_format_pap_ulotka))
        dane = self.c.fetchall()  # zwraca wartość z executa

        # print(dane)
        # print(dane[0][0], dane[0][1], dane[0][2], dane[0][3], dane[0][4], dane[0][5])
        # self.c.execute("update zlecenia set cena_za_kg=%s, waga_papieru=%s, cena_papieru=%s, ilosc_arkuszy_do_druku=%s  where id_zlecenia=%s", (cena_za_kg, dane[0][1], dane[0][2], dane[0][0]))
        self.c.execute(
            "update zlecenia set cena_za_kg=%s, waga_papieru=%s, cena_papieru=%s, ilosc_arkuszy_do_druku=%s, z_format_pap_ulotka=%s where id_zlecenia=%s",
            (cena_za_kg, dane[0][1], dane[0][2], dane[0][0], id_zlecenia, z_format_pap_ulotka))
"""