from DB import *
from Klienci import Klienci
from PoliczPapier import PoliczPapier
from Zlecenia import Zlecenia
from Ulotki import Ulotki
from Plakaty import Plakaty

class Admin(Klienci, PoliczPapier, Zlecenia, Ulotki):
    def __init__(self):

        print("Pracujesz jako administrator")
        while (True):

            dec = input("Z-dodaj zlecenie, ZU - zlecenie ulotki, ZP - zlecenie plakaty, K-dodaj Klienta, P-policz papier, Q-wyjście ").upper()
            if (dec == "Z"):
                obj = Zlecenia()
            elif (dec == "ZU"):
                obj = Ulotki()
            elif (dec == "ZP"):
                obj = Plakaty()
            elif (dec == "K"):
                obj = Klienci()
            elif (dec == "P"):
                obj = PoliczPapier()
            elif (dec == "Q"):
                break


class User(Zlecenia, Ulotki):
    def __init__(self):
        print("Pracujesz jako użytkownik")

        while(True):
            dec = input("Z-dodaj zlecenie, Q-wyjście").upper()
            if (dec == "Z"):
                obj = Zlecenia()
            elif (dec == "Q"):
                break


class Logowanie(DB):

    def __init__(self):
        super().__init__()
        self.logowanie()

    def logowanie(self):

        while (True):
            login = input("Podaj login: ")
            haslo = input("Podaj haslo: ")

            self.c.execute("SELECT id_klienta FROM klienci WHERE login=%s AND haslo=%s", (login, haslo))
            dane = self.c.fetchall()

            if (len(dane) == 0):
                print("błędne dane")

            else:
                if (dane[0][0] == 1):
                    obj = Admin()
                else:
                    obj = User()
                break


class Rejestracja(DB):
    def __init__(self):
        super().__init__()

        login = input("Wprowadź login: ")
        haslo = input("Wprowadź hasło: ")
        imie = input("Wprowadź swoje imie: ")
        nazwisko = input("Wprowadź swoje nazwisko: ")
        e_mail = input("Wprowadź swój adres e-mail: ")
        nazwa_firmy = input("Wprowadź nazwę swojej firmy")
        NIP = input("Wprowadź nr NIP swojej firmy: ")
        nr_telefonu = input("Wprowadź swój nr telefonu: ")
        adres_firmy_ulica = input("Wprowadź ulicę: ")
        adres_firmy_kod = input("Wprowadź kod pocztowy: ")
        adres_firmy_miasto = input("Podaj miejscowość: ")

        self.c.execute(
            "INSERT INTO klienci (login, haslo, imie, nazwisko, e_mail, nazwa_firmy, NIP, nr_telefonu, adres_firmy_ulica, adres_firmy_kod, adres_firmy_miasto) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)",
            (login, haslo, imie, nazwisko, e_mail, nazwa_firmy, NIP, nr_telefonu, adres_firmy_ulica, adres_firmy_kod,
             adres_firmy_miasto))

        czynapewno = input("Na pewno dodać nowe dane ? T/N ")
        if czynapewno == "T":
            self.conn.commit()
            print("Pomyślnie dodano")
        else:
            self.conn.rollback()
            print("Anulowano operację")


    #def menu(self, logowanie):

#while (True):

 #   dec = input("Z-dodaj zlecenie, K-dodaj Klienta, P-policz papier, Q-wyjście").upper()
 #   if (dec == "Z"):
  #      obj = Zlecenia()
  #  if (dec == "K"):
  #      obj = Klienci()
  #  elif (dec == "P"):
  #      obj = PoliczPapier()
  #  elif (dec == "Q"):
  #      break

#obj = DB()
#obj.menu()