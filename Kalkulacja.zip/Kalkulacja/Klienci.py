import pymysql
from DB import *

class Klienci(DB):

    def __init__(self):
        super().__init__();
        print("Tutaj Klienci")

        login = input("Wprowadź login: ")
        haslo = input("Wprowadź hasło: ")
        imie = input("Wprowadź swoje imie: ")
        nazwisko = input("Wprowadź swoje nazwisko: ")
        e_mail = input("Wprowadź swój adres e-mail: ")
        nazwa_firmy = input("Wprowadź nazwę swojej firmy" )
        NIP = input("Wprowadź nr NIP swojej firmy: ")
        nr_telefonu = input("Wprowadź swój nr telefonu: ")
        adres_firmy_ulica = input("Wprowadź ulicę: ")
        adres_firmy_kod = input("Wprowadź kod pocztowy: ")
        adres_firmy_miasto = input("Podaj miejscowość: ")

        self.c.execute("INSERT INTO klienci (login, haslo, imie, nazwisko, e_mail, nazwa_firmy, NIP, nr_telefonu, adres_firmy_ulica, adres_firmy_kod, adres_firmy_miasto) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)",
                       (login, haslo, imie, nazwisko, e_mail, nazwa_firmy, NIP, nr_telefonu, adres_firmy_ulica, adres_firmy_kod, adres_firmy_miasto))

        dec = input("Dodać nowego Klienta? T/N").upper()

        if (dec == "T"):
            self.conn.commit()
        else:
            self.conn.rollback()